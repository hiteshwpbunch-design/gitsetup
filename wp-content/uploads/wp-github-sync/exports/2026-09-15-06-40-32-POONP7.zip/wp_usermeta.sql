/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `wp_usermeta` VALUES ('1', '1', 'nickname', 'gitsetup');
INSERT INTO `wp_usermeta` VALUES ('2', '1', 'first_name', '');
INSERT INTO `wp_usermeta` VALUES ('3', '1', 'last_name', '');
INSERT INTO `wp_usermeta` VALUES ('4', '1', 'description', '');
INSERT INTO `wp_usermeta` VALUES ('5', '1', 'rich_editing', 'true');
INSERT INTO `wp_usermeta` VALUES ('6', '1', 'syntax_highlighting', 'true');
INSERT INTO `wp_usermeta` VALUES ('7', '1', 'comment_shortcuts', 'false');
INSERT INTO `wp_usermeta` VALUES ('8', '1', 'admin_color', 'modern');
INSERT INTO `wp_usermeta` VALUES ('9', '1', 'use_ssl', '0');
INSERT INTO `wp_usermeta` VALUES ('10', '1', 'show_admin_bar_front', 'true');
INSERT INTO `wp_usermeta` VALUES ('11', '1', 'locale', '');
INSERT INTO `wp_usermeta` VALUES ('12', '1', 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}');
INSERT INTO `wp_usermeta` VALUES ('13', '1', 'wp_user_level', '10');
INSERT INTO `wp_usermeta` VALUES ('14', '1', 'dismissed_wp_pointers', '');
INSERT INTO `wp_usermeta` VALUES ('15', '1', 'show_welcome_panel', '1');
INSERT INTO `wp_usermeta` VALUES ('16', '1', 'session_tokens', 'a:3:{s:64:\"15a8200816283c8a16b02c5c30c6d9c3b015f6c6dc41279d86063272703cd60f\";a:4:{s:10:\"expiration\";i:1789539864;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36\";s:5:\"login\";i:1789367064;}s:64:\"8ea1ebc0f5fd99018e7ba00a0f6d4b82dd80a904c360cbce62d1d9722147bd8e\";a:4:{s:10:\"expiration\";i:1789623885;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36\";s:5:\"login\";i:1789451085;}s:64:\"793bab88824deda38d6a1270ba069bba68ac237a774623bfde5b93fbcf9d6b81\";a:4:{s:10:\"expiration\";i:1789625510;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36\";s:5:\"login\";i:1789452710;}}');
INSERT INTO `wp_usermeta` VALUES ('17', '1', 'wp_dashboard_quick_press_last_post_id', '5');
INSERT INTO `wp_usermeta` VALUES ('18', '1', 'aioseo_newsroom_seen_version', '5.0.1.1');
INSERT INTO `wp_usermeta` VALUES ('19', '1', 'wp_persisted_preferences', 'a:4:{s:4:\"core\";a:3:{s:26:\"isComplementaryAreaVisible\";b:1;s:24:\"enableChoosePatternModal\";b:1;s:10:\"openPanels\";a:4:{i:0;s:11:\"post-status\";i:1;s:23:\"taxonomy-panel-category\";i:2;s:23:\"taxonomy-panel-post_tag\";i:3;s:24:\"yoast-seo/document-panel\";}}s:14:\"core/edit-site\";a:1:{s:12:\"welcomeGuide\";b:0;}s:9:\"_modified\";s:24:\"2026-09-15T06:30:58.434Z\";s:14:\"core/edit-post\";a:3:{s:12:\"welcomeGuide\";b:0;s:19:\"metaBoxesMainIsOpen\";b:0;s:23:\"metaBoxesMainOpenHeight\";i:641;}}');
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
