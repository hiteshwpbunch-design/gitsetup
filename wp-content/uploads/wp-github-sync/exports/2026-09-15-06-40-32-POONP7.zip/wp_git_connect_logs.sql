/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
DROP TABLE IF EXISTS `wp_git_connect_logs`;
CREATE TABLE `wp_git_connect_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `action` varchar(50) NOT NULL,
  `branch` varchar(100) NOT NULL DEFAULT '',
  `commit_hash` varchar(40) NOT NULL DEFAULT '',
  `status` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `wp_git_connect_logs` VALUES ('1', '1', 'REMOTE', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 13:18:58');
INSERT INTO `wp_git_connect_logs` VALUES ('2', '0', 'REMOTE', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 13:19:03');
INSERT INTO `wp_git_connect_logs` VALUES ('3', '0', 'FETCH', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 13:19:04');
INSERT INTO `wp_git_connect_logs` VALUES ('4', '1', 'REMOTE', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 13:19:54');
INSERT INTO `wp_git_connect_logs` VALUES ('5', '1', 'REMOTE', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 13:20:21');
INSERT INTO `wp_git_connect_logs` VALUES ('6', '1', 'REMOTE', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 13:21:26');
INSERT INTO `wp_git_connect_logs` VALUES ('7', '1', 'REMOTE', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 13:21:52');
INSERT INTO `wp_git_connect_logs` VALUES ('8', '1', 'REMOTE', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 13:22:03');
INSERT INTO `wp_git_connect_logs` VALUES ('9', '1', 'REMOTE', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 13:22:54');
INSERT INTO `wp_git_connect_logs` VALUES ('10', '1', 'REMOTE', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 13:24:12');
INSERT INTO `wp_git_connect_logs` VALUES ('11', '0', 'REMOTE', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 14:19:41');
INSERT INTO `wp_git_connect_logs` VALUES ('12', '0', 'FETCH', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 14:19:41');
INSERT INTO `wp_git_connect_logs` VALUES ('13', '0', 'REMOTE', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 15:20:29');
INSERT INTO `wp_git_connect_logs` VALUES ('14', '0', 'FETCH', '', '', 'Failed', 'fatal: not a git repository (or any of the parent directories): .git', '2026-09-14 15:20:29');
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
