/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
DROP TABLE IF EXISTS `wp_wpforms_tasks_meta`;
CREATE TABLE `wp_wpforms_tasks_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `data` longtext NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `wp_wpforms_tasks_meta` VALUES ('1', 'wpforms_process_forms_locator_scan', 'W10=', '2026-09-14 06:34:15');
INSERT INTO `wp_wpforms_tasks_meta` VALUES ('2', 'wpforms_process_purge_spam', 'W10=', '2026-09-14 06:34:15');
INSERT INTO `wp_wpforms_tasks_meta` VALUES ('3', 'wpforms_analytics_aggregate', 'W10=', '2026-09-14 06:34:15');
INSERT INTO `wp_wpforms_tasks_meta` VALUES ('4', 'wpforms_admin_addons_cache_update', 'W10=', '2026-09-14 06:34:26');
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
