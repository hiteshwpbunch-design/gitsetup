/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
DROP TABLE IF EXISTS `wp_actionscheduler_logs`;
CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `wp_actionscheduler_logs` VALUES ('1', '7', 'action created', '2026-09-14 06:32:29', '2026-09-14 06:32:29');
INSERT INTO `wp_actionscheduler_logs` VALUES ('2', '8', 'action created', '2026-09-14 06:32:29', '2026-09-14 06:32:29');
INSERT INTO `wp_actionscheduler_logs` VALUES ('11', '15', 'action created', '2026-09-14 06:33:34', '2026-09-14 06:33:34');
INSERT INTO `wp_actionscheduler_logs` VALUES ('14', '16', 'action created', '2026-09-14 06:33:36', '2026-09-14 06:33:36');
INSERT INTO `wp_actionscheduler_logs` VALUES ('17', '17', 'action created', '2026-09-14 06:33:36', '2026-09-14 06:33:36');
INSERT INTO `wp_actionscheduler_logs` VALUES ('25', '19', 'action created', '2026-09-14 06:33:39', '2026-09-14 06:33:39');
INSERT INTO `wp_actionscheduler_logs` VALUES ('26', '7', 'action started via Async Request', '2026-09-14 06:33:39', '2026-09-14 06:33:39');
INSERT INTO `wp_actionscheduler_logs` VALUES ('27', '7', 'action complete via Async Request', '2026-09-14 06:33:39', '2026-09-14 06:33:39');
INSERT INTO `wp_actionscheduler_logs` VALUES ('28', '20', 'action created', '2026-09-14 06:34:15', '2026-09-14 06:34:15');
INSERT INTO `wp_actionscheduler_logs` VALUES ('29', '21', 'action created', '2026-09-14 06:34:15', '2026-09-14 06:34:15');
INSERT INTO `wp_actionscheduler_logs` VALUES ('30', '22', 'action created', '2026-09-14 06:34:15', '2026-09-14 06:34:15');
INSERT INTO `wp_actionscheduler_logs` VALUES ('32', '24', 'action created', '2026-09-14 06:34:15', '2026-09-14 06:34:15');
INSERT INTO `wp_actionscheduler_logs` VALUES ('34', '25', 'action created', '2026-09-14 06:34:15', '2026-09-14 06:34:15');
INSERT INTO `wp_actionscheduler_logs` VALUES ('35', '26', 'action created', '2026-09-14 06:34:15', '2026-09-14 06:34:15');
INSERT INTO `wp_actionscheduler_logs` VALUES ('36', '27', 'action created', '2026-09-14 06:34:15', '2026-09-14 06:34:15');
INSERT INTO `wp_actionscheduler_logs` VALUES ('37', '28', 'action created', '2026-09-14 06:34:19', '2026-09-14 06:34:19');
INSERT INTO `wp_actionscheduler_logs` VALUES ('39', '30', 'action created', '2026-09-14 06:34:27', '2026-09-14 06:34:27');
INSERT INTO `wp_actionscheduler_logs` VALUES ('40', '22', 'action started via WP Cron', '2026-09-14 06:34:30', '2026-09-14 06:34:30');
INSERT INTO `wp_actionscheduler_logs` VALUES ('41', '22', 'action complete via WP Cron', '2026-09-14 06:34:31', '2026-09-14 06:34:31');
INSERT INTO `wp_actionscheduler_logs` VALUES ('43', '20', 'action started via WP Cron', '2026-09-14 06:34:31', '2026-09-14 06:34:31');
INSERT INTO `wp_actionscheduler_logs` VALUES ('44', '20', 'action complete via WP Cron', '2026-09-14 06:34:31', '2026-09-14 06:34:31');
INSERT INTO `wp_actionscheduler_logs` VALUES ('46', '21', 'action started via WP Cron', '2026-09-14 06:34:31', '2026-09-14 06:34:31');
INSERT INTO `wp_actionscheduler_logs` VALUES ('47', '21', 'action complete via WP Cron', '2026-09-14 06:34:31', '2026-09-14 06:34:31');
INSERT INTO `wp_actionscheduler_logs` VALUES ('49', '28', 'action started via WP Cron', '2026-09-14 06:34:31', '2026-09-14 06:34:31');
INSERT INTO `wp_actionscheduler_logs` VALUES ('50', '28', 'action complete via WP Cron', '2026-09-14 06:34:32', '2026-09-14 06:34:32');
INSERT INTO `wp_actionscheduler_logs` VALUES ('51', '34', 'action created', '2026-09-14 06:34:32', '2026-09-14 06:34:32');
INSERT INTO `wp_actionscheduler_logs` VALUES ('52', '25', 'action started via WP Cron', '2026-09-14 06:34:32', '2026-09-14 06:34:32');
INSERT INTO `wp_actionscheduler_logs` VALUES ('53', '25', 'action complete via WP Cron', '2026-09-14 06:34:32', '2026-09-14 06:34:32');
INSERT INTO `wp_actionscheduler_logs` VALUES ('54', '26', 'action started via WP Cron', '2026-09-14 06:34:32', '2026-09-14 06:34:32');
INSERT INTO `wp_actionscheduler_logs` VALUES ('55', '26', 'action complete via WP Cron', '2026-09-14 06:34:32', '2026-09-14 06:34:32');
INSERT INTO `wp_actionscheduler_logs` VALUES ('56', '30', 'action started via WP Cron', '2026-09-14 06:34:32', '2026-09-14 06:34:32');
INSERT INTO `wp_actionscheduler_logs` VALUES ('57', '30', 'action complete via WP Cron', '2026-09-14 06:34:33', '2026-09-14 06:34:33');
INSERT INTO `wp_actionscheduler_logs` VALUES ('58', '19', 'action started via Async Request', '2026-09-14 06:34:52', '2026-09-14 06:34:52');
INSERT INTO `wp_actionscheduler_logs` VALUES ('59', '19', 'action complete via Async Request', '2026-09-14 06:34:52', '2026-09-14 06:34:52');
INSERT INTO `wp_actionscheduler_logs` VALUES ('60', '35', 'action created', '2026-09-14 06:34:52', '2026-09-14 06:34:52');
INSERT INTO `wp_actionscheduler_logs` VALUES ('61', '24', 'action started via Async Request', '2026-09-14 06:35:52', '2026-09-14 06:35:52');
INSERT INTO `wp_actionscheduler_logs` VALUES ('62', '24', 'action complete via Async Request', '2026-09-14 06:35:52', '2026-09-14 06:35:52');
INSERT INTO `wp_actionscheduler_logs` VALUES ('63', '35', 'action started via Async Request', '2026-09-14 06:35:52', '2026-09-14 06:35:52');
INSERT INTO `wp_actionscheduler_logs` VALUES ('64', '35', 'action complete via Async Request', '2026-09-14 06:35:52', '2026-09-14 06:35:52');
INSERT INTO `wp_actionscheduler_logs` VALUES ('67', '37', 'action created', '2026-09-14 07:46:04', '2026-09-14 07:46:04');
INSERT INTO `wp_actionscheduler_logs` VALUES ('68', '37', 'action started via WP Cron', '2026-09-14 07:46:30', '2026-09-14 07:46:30');
INSERT INTO `wp_actionscheduler_logs` VALUES ('69', '37', 'action complete via WP Cron', '2026-09-14 07:46:30', '2026-09-14 07:46:30');
INSERT INTO `wp_actionscheduler_logs` VALUES ('72', '39', 'action created', '2026-09-14 08:47:37', '2026-09-14 08:47:37');
INSERT INTO `wp_actionscheduler_logs` VALUES ('73', '39', 'action started via Async Request', '2026-09-14 08:49:40', '2026-09-14 08:49:40');
INSERT INTO `wp_actionscheduler_logs` VALUES ('74', '39', 'action complete via Async Request', '2026-09-14 08:49:40', '2026-09-14 08:49:40');
INSERT INTO `wp_actionscheduler_logs` VALUES ('77', '41', 'action created', '2026-09-14 09:50:27', '2026-09-14 09:50:27');
INSERT INTO `wp_actionscheduler_logs` VALUES ('78', '41', 'action started via Async Request', '2026-09-14 09:52:33', '2026-09-14 09:52:33');
INSERT INTO `wp_actionscheduler_logs` VALUES ('79', '41', 'action complete via Async Request', '2026-09-14 09:52:33', '2026-09-14 09:52:33');
INSERT INTO `wp_actionscheduler_logs` VALUES ('87', '43', 'action created', '2026-09-14 10:34:34', '2026-09-14 10:34:34');
INSERT INTO `wp_actionscheduler_logs` VALUES ('88', '43', 'action started via WP Cron', '2026-09-14 10:35:45', '2026-09-14 10:35:45');
INSERT INTO `wp_actionscheduler_logs` VALUES ('89', '43', 'action complete via WP Cron', '2026-09-14 10:35:45', '2026-09-14 10:35:45');
INSERT INTO `wp_actionscheduler_logs` VALUES ('90', '44', 'action created', '2026-09-14 10:55:05', '2026-09-14 10:55:05');
INSERT INTO `wp_actionscheduler_logs` VALUES ('91', '44', 'action started via WP Cron', '2026-09-14 10:55:33', '2026-09-14 10:55:33');
INSERT INTO `wp_actionscheduler_logs` VALUES ('92', '44', 'action complete via WP Cron', '2026-09-14 10:55:33', '2026-09-14 10:55:33');
INSERT INTO `wp_actionscheduler_logs` VALUES ('95', '46', 'action created', '2026-09-14 11:56:21', '2026-09-14 11:56:21');
INSERT INTO `wp_actionscheduler_logs` VALUES ('96', '46', 'action started via WP Cron', '2026-09-14 11:57:29', '2026-09-14 11:57:29');
INSERT INTO `wp_actionscheduler_logs` VALUES ('97', '46', 'action complete via WP Cron', '2026-09-14 11:57:29', '2026-09-14 11:57:29');
INSERT INTO `wp_actionscheduler_logs` VALUES ('100', '48', 'action created', '2026-09-15 05:03:40', '2026-09-15 05:03:40');
INSERT INTO `wp_actionscheduler_logs` VALUES ('101', '48', 'action started via WP Cron', '2026-09-15 05:03:53', '2026-09-15 05:03:53');
INSERT INTO `wp_actionscheduler_logs` VALUES ('102', '48', 'action complete via WP Cron', '2026-09-15 05:03:53', '2026-09-15 05:03:53');
INSERT INTO `wp_actionscheduler_logs` VALUES ('103', '49', 'action created', '2026-09-15 05:03:53', '2026-09-15 05:03:53');
INSERT INTO `wp_actionscheduler_logs` VALUES ('104', '8', 'action started via WP Cron', '2026-09-15 05:03:53', '2026-09-15 05:03:53');
INSERT INTO `wp_actionscheduler_logs` VALUES ('105', '8', 'action complete via WP Cron', '2026-09-15 05:03:53', '2026-09-15 05:03:53');
INSERT INTO `wp_actionscheduler_logs` VALUES ('106', '50', 'action created', '2026-09-15 05:03:53', '2026-09-15 05:03:53');
INSERT INTO `wp_actionscheduler_logs` VALUES ('107', '49', 'action started via WP Cron', '2026-09-15 05:39:12', '2026-09-15 05:39:12');
INSERT INTO `wp_actionscheduler_logs` VALUES ('108', '49', 'action complete via WP Cron', '2026-09-15 05:39:14', '2026-09-15 05:39:14');
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
