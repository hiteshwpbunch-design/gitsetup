/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `wp_term_taxonomy` VALUES ('1', '1', 'category', '', '0', '1');
INSERT INTO `wp_term_taxonomy` VALUES ('2', '2', 'monsterinsights_note_category', '', '0', '0');
INSERT INTO `wp_term_taxonomy` VALUES ('3', '3', 'monsterinsights_note_category', '', '0', '0');
INSERT INTO `wp_term_taxonomy` VALUES ('4', '4', 'monsterinsights_note_category', '', '0', '0');
INSERT INTO `wp_term_taxonomy` VALUES ('5', '5', 'wp_theme', '', '0', '1');
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
